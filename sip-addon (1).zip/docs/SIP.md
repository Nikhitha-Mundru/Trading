# SIP tab

Tracks your monthly mutual fund SIP: reminds you, records payments, and shows a small growth log. It sits outside your trading limits and the gatekeeper never reads it. It stores data in its own place on the phone, separate from your trades.

It does **not** pay anything, pick funds, or fetch prices. You pay the SIP in your fund app. There is no internet access and no AI.

## Use it
1. **SIP tab, Add a SIP:** fund name, monthly amount, the day of the month it is debited (1 to 28), and the first month to track. The default start is this month, so you are not nagged about past months.
2. **Reminders:** from 3 days before the due date, a banner shows on every tab until you mark it paid. Overdue SIPs say how many days late.
3. **After it debits:** tap **Mark paid for <month>**. Missed months are caught up one at a time, oldest first.
4. **Growth:** about once a month, open your fund app, type the current value into **Save value**. Open **Monthly growth** to see invested, value and gain for each month.
5. **Real reminders:** tap **Add calendar reminder**. It makes a repeating monthly event with an alert the day before in your iPhone Calendar. If nothing happens, open the app's page in Safari instead of the home-screen app, or set a repeating reminder yourself in the Reminders app. I could not test this button on a real iPhone.
6. **Backup:** SIP tab, Export, Build CSV, Copy. Do it monthly.

## Ask tab
"When is my SIP due?" and "How is my SIP doing?" answer from this data.

## What the numbers mean
- Gain is a simple return: (value minus invested) divided by invested. It is not a yearly rate, and it ignores that your money went in at different times. Use the XIRR figure in your fund app for a proper yearly return.
- Values are typed in by you, so they are only as fresh as your last update.

## Run the tests
```
node tests/test_sip.js
node tests/test_ask.js
```

## Learn by changing it
1. Change `LEAD_DAYS` in `sip.js` from 3 to 5. Which tests fail, and why?
2. Add a "step-up" field (raise the amount each April) with the test written first.
3. Ask Copilot: "Explain how `status()` in `sip.js` decides between due, overdue and upcoming, and which edge cases the tests cover."

## Decisions worth knowing
- Day 1 to 28 only, so every month has the date.
- A SIP due on the 1st is caught in the last days of the month before.
- Deleting a SIP deletes its payments and values too, after a confirmation.
- Paused SIPs never show reminders.
