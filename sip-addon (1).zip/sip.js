// Mutual fund SIP tracker engine. It only records and reminds: you pay the SIP in your fund app.
// Separate from the trading rules on purpose: SIPs sit outside the daily limits.
// Works in the browser (window.Sip) and in Node (require).
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Sip = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  var MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  var LEAD_DAYS = 3; // start reminding this many days before the due date

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function parts(s) { var a = s.split('-'); return { y: Number(a[0]), m: Number(a[1]), d: Number(a[2] || 1) }; }
  function monthKey(date) { return date.slice(0, 7); }
  function monthIndex(key) { var p = parts(key + '-01'); return p.y * 12 + p.m - 1; }
  function keyFromIndex(i) { return Math.floor(i / 12) + '-' + pad(i % 12 + 1); }
  function dayNumber(s) { var p = parts(s); return Math.round(Date.UTC(p.y, p.m - 1, p.d) / 86400000); }
  function fromDayNumber(n) { return new Date(n * 86400000).toISOString().slice(0, 10); }
  function dueDate(sip, key) { return key + '-' + pad(sip.day); }
  function shortDate(s) { var p = parts(s); return p.d + ' ' + MONTHS[p.m - 1]; }
  function plural(n, w) { return n + ' ' + w + (n === 1 ? '' : 's'); }
  function rs(n) { return '\u20B9' + (Math.round(n * 100) / 100); }

  function validate(sip) {
    if (!sip.name || !String(sip.name).trim()) return 'Give the SIP a name.';
    if (!(typeof sip.amount === 'number' && isFinite(sip.amount) && sip.amount > 0)) return 'Amount must be more than zero.';
    if (!(Number.isInteger(sip.day) && sip.day >= 1 && sip.day <= 28)) return 'Pick a day from 1 to 28, so every month has it.';
    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(sip.start || '')) return 'Pick the start month.';
    return '';
  }

  // Where is this SIP today? Looks at every installment month from the start month until
  // the month that contains (today + 3 days), so a due date on the 1st is caught in late month.
  function status(sip, entries, today, lead) {
    if (sip.active === false) return { state: 'paused' };
    lead = lead === undefined ? LEAD_DAYS : lead;
    var paid = {};
    (entries || []).forEach(function (e) { if (e.sipId === sip.id) paid[e.month] = true; });
    var t = dayNumber(today), horizon = t + lead;
    var startIdx = monthIndex(sip.start), endIdx = monthIndex(monthKey(fromDayNumber(horizon)));
    var pending = [];
    for (var i = startIdx; i <= endIdx; i++) {
      var key = keyFromIndex(i);
      if (paid[key]) continue;
      var due = dueDate(sip, key), late = t - dayNumber(due);
      if (dayNumber(due) <= horizon) pending.push({ month: key, due: due, late: late });
    }
    if (pending.length) {
      var first = pending[0], missed = pending.filter(function (p) { return p.late > 0; }).length;
      if (first.late > 0) return { state: 'overdue', month: first.month, due: first.due, days: first.late, missed: missed };
      return { state: 'due', month: first.month, due: first.due, days: 0 - first.late, missed: 0 };
    }
    var j = startIdx;
    while (paid[keyFromIndex(j)]) j++;
    var next = dueDate(sip, keyFromIndex(j));
    return { state: 'upcoming', month: keyFromIndex(j), due: next, days: dayNumber(next) - t, paidThisMonth: !!paid[monthKey(today)] };
  }

  function describe(st) {
    if (st.state === 'paused') return 'paused';
    if (st.state === 'overdue') return 'overdue by ' + plural(st.days, 'day') + ' (due ' + shortDate(st.due) + ')' + (st.missed > 1 ? '; ' + st.missed + ' months unpaid' : '');
    if (st.state === 'due') return st.days === 0 ? 'due today' : 'due in ' + plural(st.days, 'day') + ' (' + shortDate(st.due) + ')';
    return (st.paidThisMonth ? 'paid for this month. ' : '') + 'next due ' + shortDate(st.due) + ' (in ' + plural(st.days, 'day') + ')';
  }

  function latestSnapshot(sipId, snapshots) {
    var best = null;
    (snapshots || []).forEach(function (s) { if (s.sipId === sipId && (!best || s.date >= best.date)) best = s; });
    return best;
  }

  // Simple return, not annualised. Value is typed in by you from your fund app.
  function summary(sips, entries, snapshots) {
    var rows = sips.map(function (s) {
      var invested = (entries || []).filter(function (e) { return e.sipId === s.id; }).reduce(function (a, e) { return a + e.amount; }, 0);
      var snap = latestSnapshot(s.id, snapshots), value = snap ? snap.value : null;
      return { sipId: s.id, name: s.name, invested: invested, value: value, valueDate: snap ? snap.date : null,
               gain: value === null ? null : value - invested,
               pct: value === null || invested <= 0 ? null : (value - invested) / invested * 100 };
    });
    return { rows: rows, investedAll: rows.reduce(function (a, r) { return a + r.invested; }, 0) };
  }

  // One row per month that has a payment or a value, oldest first.
  function growthLog(sip, entries, snapshots) {
    var mine = (entries || []).filter(function (e) { return e.sipId === sip.id; });
    var snaps = (snapshots || []).filter(function (s) { return s.sipId === sip.id; });
    var keys = {};
    mine.forEach(function (e) { keys[monthKey(e.date)] = true; });
    snaps.forEach(function (s) { keys[monthKey(s.date)] = true; });
    return Object.keys(keys).sort().map(function (key) {
      var snap = null;
      snaps.forEach(function (s) { if (monthKey(s.date) === key && (!snap || s.date >= snap.date)) snap = s; });
      var cutoff = snap ? snap.date : key + '-31';
      var invested = mine.filter(function (e) { return e.date <= cutoff; }).reduce(function (a, e) { return a + e.amount; }, 0);
      var value = snap ? snap.value : null;
      return { month: key, invested: invested, value: value,
               gain: value === null ? null : value - invested,
               pct: value === null || invested <= 0 ? null : (value - invested) / invested * 100 };
    });
  }

  function icsText(s) { return String(s).replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\r?\n/g, '\\n'); }

  // A repeating monthly calendar event with an alert the day before. iPhone Calendar sends the real reminder.
  function ics(sip, today) {
    var p = parts(today), key = p.d <= sip.day ? monthKey(today) : keyFromIndex(monthIndex(monthKey(today)) + 1);
    var first = dueDate(sip, key).replace(/-/g, '');
    return ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Gatekeeper//SIP//EN', 'BEGIN:VEVENT',
      'UID:sip-' + sip.id + '@gatekeeper', 'DTSTAMP:' + today.replace(/-/g, '') + 'T000000Z',
      'DTSTART;VALUE=DATE:' + first, 'RRULE:FREQ=MONTHLY;BYMONTHDAY=' + sip.day,
      'SUMMARY:' + icsText('SIP due: ' + sip.name + ' (Rs ' + sip.amount + ')'),
      'DESCRIPTION:' + icsText('Pay the SIP in your fund app, then mark it paid in the Gatekeeper app.'),
      'BEGIN:VALARM', 'TRIGGER:-P1D', 'ACTION:DISPLAY', 'DESCRIPTION:SIP due tomorrow', 'END:VALARM',
      'END:VEVENT', 'END:VCALENDAR', ''].join('\r\n');
  }

  return { status: status, describe: describe, summary: summary, growthLog: growthLog, ics: ics, validate: validate,
           monthKey: monthKey, shortDate: shortDate, rs: rs, LEAD_DAYS: LEAD_DAYS };
});
