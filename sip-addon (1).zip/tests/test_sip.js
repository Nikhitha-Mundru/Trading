// Run with: node tests/test_sip.js
const assert = require('assert');
const Sip = require('../sip.js');
let n = 0;
function test(name, fn) { try { fn(); n++; } catch (e) { console.log('FAIL', name, '\n  ', e.message); process.exitCode = 1; } }
const sip = (over) => Object.assign({ id: 'a', name: 'Index fund', amount: 2000, day: 5, start: '2026-11', active: true }, over);
const paid = (month, date) => ({ sipId: 'a', month, date: date || month + '-05', amount: 2000 });
const st = (s, entries, today) => Sip.status(s, entries, today);

test('4 days before: upcoming', () => { const r = st(sip(), [], '2026-11-01'); assert.deepStrictEqual([r.state, r.days, r.due], ['upcoming', 4, '2026-11-05']); });
test('3 days before: due', () => { const r = st(sip(), [], '2026-11-02'); assert.deepStrictEqual([r.state, r.days], ['due', 3]); });
test('due today', () => { const r = st(sip(), [], '2026-11-05'); assert.deepStrictEqual([r.state, r.days], ['due', 0]); assert.strictEqual(Sip.describe(r), 'due today'); });
test('one day late: overdue', () => { const r = st(sip(), [], '2026-11-06'); assert.deepStrictEqual([r.state, r.days, r.missed], ['overdue', 1, 1]); assert.ok(Sip.describe(r).startsWith('overdue by 1 day (due 5 Nov)')); });
test('paid this month: next is next month', () => {
  const r = st(sip(), [paid('2026-11')], '2026-11-20');
  assert.deepStrictEqual([r.state, r.month, r.due, r.days, r.paidThisMonth], ['upcoming', '2026-12', '2026-12-05', 15, true]);
  assert.strictEqual(Sip.describe(r), 'paid for this month. next due 5 Dec (in 15 days)');
});
test('paid, then 2 days before next month: due', () => { const r = st(sip(), [paid('2026-11')], '2026-12-03'); assert.deepStrictEqual([r.state, r.month, r.days], ['due', '2026-12', 2]); });
test('missed two months counts both and points at the first', () => {
  const r = st(sip({ start: '2026-10' }), [], '2026-11-20');
  assert.deepStrictEqual([r.state, r.month, r.days, r.missed], ['overdue', '2026-10', 46, 2]);
  assert.ok(Sip.describe(r).includes('2 months unpaid'));
});
test('catching up an old month moves on to the next one', () => {
  const r = st(sip({ start: '2026-10' }), [paid('2026-10', '2026-11-10')], '2026-11-20');
  assert.deepStrictEqual([r.state, r.month, r.missed], ['overdue', '2026-11', 1]);
});
test('future start month is upcoming', () => { const r = st(sip({ start: '2026-12' }), [], '2026-11-16'); assert.deepStrictEqual([r.state, r.due, r.days, r.paidThisMonth], ['upcoming', '2026-12-05', 19, false]); });
test('due date on the 1st is caught at the end of the month', () => {
  const r = st(sip({ day: 1 }), [paid('2026-11', '2026-11-01')], '2026-11-29');
  assert.deepStrictEqual([r.state, r.month, r.days], ['due', '2026-12', 2]);
});
test('year wrap', () => {
  const r = st(sip({ day: 2, start: '2026-12' }), [paid('2026-12', '2026-12-02')], '2026-12-30');
  assert.deepStrictEqual([r.state, r.month, r.days], ['due', '2027-01', 3]);
});
test('paused SIP never nags', () => assert.strictEqual(st(sip({ active: false }), [], '2026-11-30').state, 'paused'));
test('other SIPs payments do not count', () => assert.strictEqual(st(sip(), [{ sipId: 'zzz', month: '2026-11', date: '2026-11-05', amount: 1 }], '2026-11-06').state, 'overdue'));

test('summary: invested, value, gain, percent by hand', () => {
  const entries = [paid('2026-09'), paid('2026-10'), paid('2026-11')];
  const snaps = [{ sipId: 'a', date: '2026-10-20', value: 4100 }, { sipId: 'a', date: '2026-11-10', value: 6300 }];
  const s = Sip.summary([sip()], entries, snaps);
  assert.strictEqual(s.investedAll, 6000);
  const r = s.rows[0];
  assert.deepStrictEqual([r.invested, r.value, r.gain, r.pct], [6000, 6300, 300, 5]); // latest snapshot wins
});
test('summary without a value leaves gain empty, not zero', () => {
  const r = Sip.summary([sip()], [paid('2026-11')], []).rows[0];
  assert.deepStrictEqual([r.invested, r.value, r.gain, r.pct], [2000, null, null, null]);
});
test('growth log by hand', () => {
  const entries = [paid('2026-09'), paid('2026-10'), paid('2026-11')];
  const log = Sip.growthLog(sip(), entries, [{ sipId: 'a', date: '2026-11-10', value: 3300 }]);
  assert.deepStrictEqual(log.map(r => [r.month, r.invested, r.value, r.gain, r.pct]),
    [['2026-09', 2000, null, null, null], ['2026-10', 4000, null, null, null], ['2026-11', 6000, 3300 - 0, 3300 - 6000, (3300 - 6000) / 6000 * 100]]);
});
test('growth log: value is compared with what was paid by that date', () => {
  const entries = [{ sipId: 'a', month: '2026-11', date: '2026-11-05', amount: 1000 }, { sipId: 'a', month: '2026-12', date: '2026-12-05', amount: 1000 }];
  const log = Sip.growthLog(sip(), entries, [{ sipId: 'a', date: '2026-11-20', value: 1050 }]);
  assert.deepStrictEqual(log.map(r => [r.month, r.invested, r.value, r.gain]), [['2026-11', 1000, 1050, 50], ['2026-12', 2000, null, null]]);
});
test('ics: repeating monthly event with a day-before alert', () => {
  const t = Sip.ics(sip(), '2026-11-16');
  assert.ok(t.includes('DTSTART;VALUE=DATE:20261205') && t.includes('RRULE:FREQ=MONTHLY;BYMONTHDAY=5') && t.includes('TRIGGER:-P1D'));
  assert.ok(Sip.ics(sip(), '2026-11-03').includes('DTSTART;VALUE=DATE:20261105'));
  assert.ok(Sip.ics(sip({ day: 5 }), '2026-12-31').includes('DTSTART;VALUE=DATE:20270105'));
  assert.ok(t.includes('\r\n') && t.endsWith('END:VCALENDAR\r\n'));
});
test('ics escapes commas and semicolons in names', () => assert.ok(Sip.ics(sip({ name: 'Fund, A; B' }), '2026-11-03').includes('SUMMARY:SIP due: Fund\\, A\\; B')));
test('validate', () => {
  assert.strictEqual(Sip.validate(sip()), '');
  assert.ok(Sip.validate(sip({ name: ' ' })));
  assert.ok(Sip.validate(sip({ amount: 0 })));
  assert.ok(Sip.validate(sip({ amount: NaN })));
  assert.ok(Sip.validate(sip({ day: 29 })));
  assert.ok(Sip.validate(sip({ day: 5.5 })));
  assert.ok(Sip.validate(sip({ start: '2026-13' })));
});
console.log(process.exitCode ? 'some tests failed' : 'all ' + n + ' sip tests pass');
